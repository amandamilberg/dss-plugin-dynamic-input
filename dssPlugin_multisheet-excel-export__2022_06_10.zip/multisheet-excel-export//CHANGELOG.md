# Changelog

## [Version 1.0.1](https://github.com/dataiku/dss-plugin-ml-assisted-labeling/releases/tag/v1.0.1) - New hotfix release - 2022-03
- Changed documentation URL