Current Version: 1.0.0

# Plugin information

This plugin converts several DSS datasets to one multi-sheet excel (`.xlsx`) file containing one sheet per input dataset.

# Prerequisites

The installation setup for this plugin follows the standard DSS code environment creation procedure.
This plugin relies on the [openpyxl](https://openpyxl.readthedocs.io/en/stable/) Python module.

# How it works

Once the plugin is successfully installed, select the datasets that you want to export as one excel file. 
Then run the Multi-Sheet Excel Export recipe from the flow. 
It will create a folder in your flow containing the output `.xls` file. Each sheet of this file contains one dataset and is named after this dataset.
 
## Running tests

In order to run the tests contained in `python-test\`, launch the following command from the plugin root directory: 
`PYTHONPATH=$PYTHONPATH:/path/to/python-lib pytest`

### Walmart Customizations
Updated code for Walmart:  Change cache output location to /tmp/tmp_data instead of user /home/dir

File updated:
multisheet-excel-export/python-lib/cache_utils.py

from: self.tmp_output_dir = None
to: self.tmp_output_dir = '/tmp' 

##home_dir = pwd.getpwuid(os.getuid()).pw_dir
home_dir = '/tmp/tmp_data'