### Create connection

import dataiku
import dataikuapi
import json

#myconnvar = dataiku.get_custom_variables()["connection_name"]

remote_host = "http://10.64.6.32:12000"
remote_apiKey = "96GMWQC58E3LLHJ16B1TQ8L2DVT72OMJ"
#copy_connection= "data-discovery-presto"
copy_connection= dataiku.get_custom_variables()["connection_name"]

remote = dataikuapi.DSSClient(remote_host, remote_apiKey)
local = dataiku.api_client()

conn_local = local.list_connections()

if (copy_connection != None):
    v = conn_local.get(copy_connection)
    _params = v.get("params")
    _usable_by = v.get("usableBy")
    _allowed_groups = v.get("allowedGroups")
    _type = v.get("type")
    
    new_connection = remote.create_connection(copy_connection, _type, params=_params, usable_by=_usable_by, allowed_groups=_allowed_groups)

    print(remote.list_connections().get(copy_connection))
