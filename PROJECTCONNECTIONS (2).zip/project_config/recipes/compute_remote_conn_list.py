
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import dataikuapi




client = dataiku.api_client()

copy_projectkey= dataiku.get_custom_variables()["project_key"]

#project = client.get_project("ADHOC_AVT")

remote_host = "http://10.64.6.32:12000"
remote_apiKey = "96GMWQC58E3LLHJ16B1TQ8L2DVT72OMJ"
remote = dataikuapi.DSSClient(remote_host, remote_apiKey)

#connections = remote.list_connections()

copy_connection= dataiku.get_custom_variables()["connection_name"]
infra= dataiku.get_custom_variables()["target_infra"]

prod = "https://dataiku.walmart.com/"
prod_key = "CNvyms96gLqEbSkFGq1Usav6fWam7zwx"
non_prod = "https://devauto-dataiku.walmart.com/"
non_prod_key = "CbnQS5ZcFARu7vInnjpY44UCC4osjhJm" 



if infra == "test":
    remote_host = "http://10.64.6.32:12000"
    remote_apiKey = "96GMWQC58E3LLHJ16B1TQ8L2DVT72OMJ"
    remote = dataikuapi.DSSClient(remote_host, remote_apiKey)
    remote._session.verify = False
    connections = remote.list_connections()
    
    project_connections_df =  pd.DataFrame.from_dict(connections, orient='index', columns=['name']) 

    # Write recipe outputs
    project_connections = dataiku.Dataset("remote_conn_list")
    project_connections.write_with_schema(project_connections_df)

elif infra == "non-prod":
   
        
  # print "1 - Got a false expression value"
    remote_host =  non_prod #"https://devauto-dataiku.walmart.com/"
    remote_apiKey = non_prod_key #"CbnQS5ZcFARu7vInnjpY44UCC4osjhJm"
    remote = dataikuapi.DSSClient(remote_host, remote_apiKey)
    remote._session.verify = False
    connections = remote.list_connections()
    project_connections_df =  pd.DataFrame.from_dict(connections, orient='index', columns=['name']) 

    # Write recipe outputs
    project_connections = dataiku.Dataset("remote_conn_list")
    project_connections.write_with_schema(project_connections_df)
    
elif infra == "prod":
  # print "1 - Got a false expression value"
    remote_host =  prod #"https://devauto-dataiku.walmart.com/"
    remote_apiKey = prod_key #"CbnQS5ZcFARu7vInnjpY44UCC4osjhJm"
    remote = dataikuapi.DSSClient(remote_host, remote_apiKey)
    remote._session.verify = False
    connections = remote.list_connections()
    project_connections_df =  pd.DataFrame.from_dict(connections, orient='index', columns=['name']) 

    # Write recipe outputs
    project_connections = dataiku.Dataset("remote_conn_list")
    project_connections.write_with_schema(project_connections_df)
    
else:
    print (infra)
    
    

        
         

